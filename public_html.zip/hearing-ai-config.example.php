<?php
// Rename this file to hearing-ai-config.php and place it OUTSIDE public_html.
// Never paste this key into HTML, CSS, JavaScript, or a public .txt file.
return [
    'api_key' => 'YOUR_OPENAI_API_KEY',
    'model' => 'gpt-4.1-mini',
    'allowed_origins' => ['https://sophiabao.com', 'https://www.sophiabao.com'],
    'requests_per_ip_per_hour' => 10,
    'requests_per_day' => 100,
];
